/**
 * @file course.c
 * @author Sihoon Park (parks138@mcmaster.ca)
 * @brief Functions for course type
 * @version 0.1
 * @date 2022-04-04
 * 
 * @copyright Copyright (c) 2022
 * 
 */


#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 

/**
 * @brief Enrolling students in a course
 * 
 * First increase total number of students for the course
 * If this is the first student,  then we use calloc to allocate space on heap and preset all values to 0
 * Other cases, use realloc to re-allocate the space for students
 * In the list of students set the (total_students - 1)th place to be the input of student
 * 
 * @param course Input of course 
 * @param student Input of student that we will enroll
 */

void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}


/**
 * @brief Print courses
 * First print course name
 *       print course code
 *       print total number of student
 *       lastly print each students in the students list
 * 
 * @param course Input of course that we want to print
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  //print each students
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief Check which student has the highest average
 * 
 * First, create three variables student_average that will save the current student average
 *                               max_average that will save the highest average
 *                               student that will save the address of the top student.                             
 * 
 * For the number of total students, calculate student's average and if the average is higher than max average
 * Change max average to the current student's average
 * Change top student to the current student
 * 
 * Return the top student
 * 
 * @param course Input of course 
 * @return Student* Output of the top student
 */
Student* top_student(Course* course)
{
  //if there is no student, return NULL
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]); //set the maximum average to be the first student's average
  Student *student = &course->students[0]; //set the top student to be the first student
 
  //start from 1 because we already set the maximum average to be the [0] fo the students list.
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief Create a list of students who pass the course
 * 
 * Create two variables count that will count the number of passing students
 *                      passing, a list of passing students
 * 
 * It will first count the number of passing students
 * Run a for loop for the numbers of total_students if that student's avrage is above 50 then increase count by 1
 * 
 * Use calloc and dynamically allocated space for the passing students list, use count to size the list
 * Create int j that will determine the (j)th passing student
 * 
 * Run a for loop for theh numbers of total_students, if average is higher than 50
 * Then add the student into the passing list and increase j by 1
 * 
 * Since count is the number of passing students, let *total_passing = count
 * Return the list of passing student
 * 
 * @param course Input of course
 * @param total_passing address of int variable that will save the number of total passing students
 * @return Student* Return a list of passing students
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  //counting the number of passing students
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student));

  //storing passing students in a list
  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}