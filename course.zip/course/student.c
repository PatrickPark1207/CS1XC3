/**
 * @file student.c
 * @author Sihoon Park (parks138@mcmaster.ca)
 * @brief Functions for student type
 * @version 0.1
 * @date 2022-04-04
 * 
 * @copyright Copyright (c) 2022
 * 
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * @brief add a grade in a student grades list
 * 
 * First, it will increase the num_grade by one
 * If it is the first grade, then we use calloc to allocate space on heap and preset all values to 0
 * Other cases, use realloc to re-allocate the space for grades
 * Save the given input grade to the (num_grades - 1)th place of grades list
 * 
 * @param student input of a student that has grades list
 * @param grade input of the number we add to the grades list
 */

void add_grade(Student* student, double grade)
{
  student->num_grades++;
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  student->grades[student->num_grades - 1] = grade;
}

/**
 * @brief Find a student's average 
 * 
 * For the number of grades, add each grade into total
 * Calculate the average by divide total by the number of grades
 * Return the average
 * 
 * @param student input of a student
 * @return double output of an average
 */

double average(Student* student)
{
  if (student->num_grades == 0) return 0;

  //calculate total
  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  return total / ((double) student->num_grades);
}

/**
 * @brief Print student info
 * 
 * First print name, in the order of first name last name
 *       print id,
 *       print grades to the hundredth place by using for loop, for num_grades times
 *       print average with use of avrage
 * 
 * @param student input of student that will be printed
 */
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  //print each grade
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}


/**
 * @brief generate a random student
 * 
 * Create a new_student and allocates space on heap and preset all values to 0
 * Randomly set the student's first name and second name
 * Run a for loop to randomly set the student's id with use of ASCII code
 * Run a for loop to set grades for the student with use of add_grades function
 * This for loop will run for the given input grades times
 * Return the generated student
 * 
 * @param grades number of grades
 * @return Student* output of the generated student
 */

Student* generate_random_student(int grades)
{
  // list of first names
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  // list of last names
  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  Student *new_student = calloc(1, sizeof(Student));

  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);


  // adding 48 because of ASCII code
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  //assign grade that is larger than 25 for 'grades' times
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}