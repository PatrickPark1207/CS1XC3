/**
 * @file course.h
 * @author Sihoon Park (parks138@mcmaster.ca)
 * @brief 
 * @version 0.1
 * @date 2022-04-04
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "student.h"
#include <stdbool.h>
 

/**
 * @brief Type Course includes
 *          name of the course (in string)
 *          course of (in string)
 *          address of students
 *          total number of students (in int)
 * 
 */
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

//More explanation in the course.c file
void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


