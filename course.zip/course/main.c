/**
 * @file main.c
 * @author Sihoon Park (parks138@mcmaster.ca)
 * @brief Main function
 * @version 0.1
 * @date 2022-04-04
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"


/**
 * @brief Testing functions
 * 
 * First create a course using calloc, assign name and code for the course
 * 
 * Then enroll 20 students with 8 grades
 * Print all information about the course
 * 
 * Create a Student type variable student
 * Find and store the top student in the student variable
 * Print top student
 * 
 * Create a int variable total_passing to save the total number of passing students
 * Make a list of passing students and store the result of passing function
 * print all passing students.
 * 
 * @return int returning 0
 */
int main()
{
  //random numbers
  srand((unsigned) time(NULL));

  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  //enrolling students
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);

  //find and print top student
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  //find and print passing students
  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}